var earlyWarnInfoTable;
var sysInfoTable;
var earlyWarnId;
var sysInfoEditTable;
var sysIds=[];

function getEarlyWarnInfoList() {
    $('#earlyWarnInfo').dataTable().fnDestroy();
    earlyWarnInfoTable = $("#earlyWarnInfo").dataTable({
        "bDestory": true,
        "bFilter": false,

        "sAjaxSource": "mesEarlyWarn.do?pageEarlyWarnInfoAjax",
        "bProcessing": true,
        "searching": false, //去掉搜索框
        "bLengthChange": false,// 是否允许自定义每页显示条数.
        "aLengthMenu": [
            [1, 5, 10, 25, 50, 100, -1],
            [1, 5, 10, 25, 50, 100, "所有"]
        ],
        "bServerSide": true,
        "iDisplayLength": 10,
        "oLanguage": {//语言设置
            "sLengthMenu": "每页显示  _MENU_ 条记录",
            "sInfo": "从 _START_ 到 _END_ /共 _TOTAL_ 条数据",
            "oPaginate": {
                "sFirst": "首页",
                "sPrevious": "前一页",
                "sNext": "后一页",
                "sLast": "尾页"
            },
            "sZeroRecords": "抱歉， 没有找到",
            "sInfoEmpty": "没有数据"
        },
//        "sAjaxDataProp": 'object',  //这个改写默认取值的JSON对象
        "aoColumns": [
            {
                "mDataProp": 'id',
                "sTitle": "编号",
                "bSortable": false
            },
            {
                "mDataProp": 'description',
                "sTitle": "描述",
                "bSortable": false
            },
            {
                "mDataProp": 'flag',
                "sTitle": "是否有效",
                "bSortable": false
            },
            {
                "mDataProp": 'status',
                "sTitle": "开启状态",
                "bSortable": false
            },
            {
                "mDataProp": 'errLevel',
                "sTitle": "预警等级",
                "bSortable": false
            },
            {
                "mDataProp": 'count',
                "sTitle": "数量",
                "bSortable": false
            }
        ],
        "aoColumnDefs": [
            {
                sDefaultContent: '',
                aTargets: [ '_all' ]
            }
        ],
        "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
        	if (aData['flag'] == 0) {
                $('td:eq(2)', nRow).html(
                    "有效");
            }else if (aData['flag'] == 1) {
                $('td:eq(2)', nRow).html(
                "无效");
            }
        	
        	if (aData['status'] == 0) {
                $('td:eq(3)', nRow).html(
                    " 开启 ");
            }else if (aData['status'] == 1) {
                $('td:eq(3)', nRow).html(
                " 停止 ");
            }
//        	
        	if (aData['errLevel'] == 1) {
                $('td:eq(4)', nRow).html(
                    " 警告 ");
            }else if (aData['errLevel'] == 2) {
                $('td:eq(4)', nRow).html(
                " 异常 ");
            }
        	
           
        }
    });

}






function getSysInfoList(id) {
    $('#sysInfo').dataTable().fnDestroy();
    sysInfoTable = $("#sysInfo").dataTable({
        "bDestory": true,
        "bFilter": false,

        "sAjaxSource": "sysOperate.do?pageSysInfoByEWId&ewId="+id,
        "bProcessing": true,
        "searching": false, //去掉搜索框
        "bLengthChange": false,// 是否允许自定义每页显示条数.
        "aLengthMenu": [
            [1, 5, 10, 25, 50, 100, -1],
            [1, 5, 10, 25, 50, 100, "所有"]
        ],
        "bServerSide": true,
        "iDisplayLength": 10,
        "oLanguage": {//语言设置
            "sLengthMenu": "每页显示  _MENU_ 条记录",
            "sInfo": "从 _START_ 到 _END_ /共 _TOTAL_ 条数据",
            "oPaginate": {
                "sFirst": "首页",
                "sPrevious": "前一页",
                "sNext": "后一页",
                "sLast": "尾页"
            },
            "sZeroRecords": "抱歉， 没有找到",
            "sInfoEmpty": "没有数据"
        },
//        "sAjaxDataProp": 'object',  //这个改写默认取值的JSON对象
        "aoColumns": [
            {
                "mDataProp": 'id',
                "sTitle": "编号",
                "bSortable": false
            },
            {
                "mDataProp": 'sysCode',
                "sTitle": "代码",
                "bSortable": false
            },
            {
                "mDataProp": 'sysDesc',
                "sTitle": "描述",
                "bSortable": false
            },
            {
                "mDataProp": null,
                "sTitle": "操作",
                "bSortable": true
            }
        ],
        "aoColumnDefs": [
            {
                sDefaultContent: '',
                aTargets: [ '_all' ]
            }
        ],
        "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
        	$('td:eq(3)', nRow).html(
                    "<a class='btn btn-info btn-xs' onclick='deleteSysInfo(\""
                    + aData['id'] + "\")'>删除</a>");
        	sysIds.push(aData['id']);
        }

    });
}
/*单击新增*/
$("#sysInfoAdd").click(function(){
	sysInfoAdd();
});
function sysInfoAdd(){
	$('#sysInfoEdit').dataTable().fnDestroy();
	$("#sysInfoEdit").dataTable({
        "bDestory": true,
        "bFilter": false,

        "sAjaxSource": "sysOperate.do?pageSysInfoAjax",
        "bProcessing": true,
        "searching": false, //去掉搜索框
        "bLengthChange": false,// 是否允许自定义每页显示条数.
        "aLengthMenu": [
            [1, 5, 10, 25, 50, 100, -1],
            [1, 5, 10, 25, 50, 100, "所有"]
        ],
        "bServerSide": true,
        "iDisplayLength": 10,
        "oLanguage": {//语言设置
            "sLengthMenu": "每页显示  _MENU_ 条记录",
            "sInfo": "从 _START_ 到 _END_ /共 _TOTAL_ 条数据",
            "oPaginate": {
                "sFirst": "首页",
                "sPrevious": "前一页",
                "sNext": "后一页",
                "sLast": "尾页"
            },
            "sZeroRecords": "抱歉， 没有找到",
            "sInfoEmpty": "没有数据"
        },
//        "sAjaxDataProp": 'object',  //这个改写默认取值的JSON对象
        "aoColumns": [
			{
			    "mDataProp": 'id',
			    "sTitle": "选择",
			    "bSortable": false
			},
            {
                "mDataProp": 'id',
                "sTitle": "编号",
                "bSortable": false
            },
            {
                "mDataProp": 'sysCode',
                "sTitle": "代码",
                "bSortable": false
            },
            {
                "mDataProp": 'sysDesc',
                "sTitle": "描述",
                "bSortable": false
            }
        ],
        "aoColumnDefs": [
            {
                sDefaultContent: '',
                aTargets: [ '_all' ]
            }
        ],
        "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
        	var flag=false;
        	sysIds.forEach(function(sysId){
        		if(sysId==aData['id']){
        			flag=true;
        		}else{
        			flag=false;
        		}
        	});
        	if(flag==true){
        		$('td:eq(0)', nRow).html(
                        "<input type='checkbox' name='sysid' value='"+aData['id']+"' checked  />");
        	}else{
        		$('td:eq(0)', nRow).html(
                        "<input type='checkbox' name='sysid' value='"+aData['id']+"'  />");
        	}

        }

    });
}
/*单击保存*/ 
$("#ewSysInfoSave").click(function(){
	var ids=[];
	$("#sysInfoEdit tbody tr").each(function(){
		var checkbox=$(this).children("td").eq(0).children("input:checkbox");
		if(checkbox.attr("checked")){
			ids.push(checkbox.val());
		}
	});
	
});


$('#earlyWarnInfo').on('click', 'tbody tr', function () {
	sysIds=[]; //将sysIds数组中的数据清空,然后当调用系统查询是再赋值
    // 设置选中样式
    if ($(this).hasClass('selected')) {
        $(this).removeClass('selected');
    } else {
        earlyWarnInfoTable.$('tr.selected').removeClass('selected');
        $(this).addClass('selected');
    }
    var sTitle;
    var nTds = $('td', this);
    earlyWarnId = $(nTds[0]).text();
    getSysInfoList(earlyWarnId);
    /*
     $('#users').dataTable().fnDestroy();
     $('#users').dataTable().fnClearTable()
     $("#users").dataTable({
     "sAjaxSource": "/userGroup.do?selectUsersByGroupid&userGroupId=" + groupId,
     "bRetrieve": true
     })
     */
    /* 
     $.ajax({
     type: "post",
     url: "/userGroup.do?selectUsersByGroupid",
     dataType: "json",
     data: {
     "userGroupId": groupId
     },
     error: function () {
     },
     success: function (data) {
     $('#users').DataTable({
     data: data
     });
     }
     });
     */
    /*
     $("#default").val(dicName);
     $('#grid-sysParam').dataTable().fnDestroy();
     getItemList(s);
     */
    /*
     */
});
































































var groupTable;
var usersTable;
var userEditTable;
var groupDlg;

var groupId = 0;

$('#userAdd').click(function () {
    $('#userEdit').dataTable().fnDestroy();
    userEditForm(groupId);
    $('#groupDlg').dialog('open');
    return false;
});




$('#usersEdit').on('click', 'tbody tr', function () {
    // 设置选中样式
    if ($(this).hasClass('selected')) {
        $(this).removeClass('selected');
    } else {
        groupTable.$('tr.selected').removeClass('selected');
        $(this).addClass('selected');
    }
    var sTitle;
    var nTds = $('td', this);
    var groupId = $(nTds[1]).id;
    alert(groupId);
    /*
     $('#users').dataTable().fnDestroy();
     $('#users').dataTable().fnClearTable()
     $("#users").dataTable({
     "sAjaxSource": "/userGroup.do?selectUsersByGroupid&userGroupId=" + groupId,
     "bRetrieve": true
     })
     */
    /*
     $.ajax({
     type: "post",
     url: "/userGroup.do?selectUsersByGroupid",
     dataType: "json",
     data: {
     "userGroupId": groupId
     },
     error: function () {
     },
     success: function (data) {
     $('#users').DataTable({
     data: data
     });
     }
     });
     */
    /*
     $("#default").val(dicName);
     $('#grid-sysParam').dataTable().fnDestroy();
     getItemList(s);
     */
    /*
     */
});



$(function () {
	getEarlyWarnInfoList();
	getSysInfoList(-1);
});